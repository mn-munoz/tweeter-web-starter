export interface Service {

}